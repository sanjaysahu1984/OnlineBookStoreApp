npm install

**check for error

npm start
