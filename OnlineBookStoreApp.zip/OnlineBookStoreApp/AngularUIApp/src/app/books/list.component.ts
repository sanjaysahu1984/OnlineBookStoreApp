﻿import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';

import { BookService, AccountService } from '@app/_services';
import { User, BookUser } from '@app/_models';
import { createElementCssSelector } from '@angular/compiler';

@Component({ templateUrl: 'list.component.html' })
export class ListComponent implements OnInit {
    books = null;
    user: User;
    isAdmin:boolean=false;

    constructor(private bookService: BookService, private accountService: AccountService) {
        this.user = this.accountService.userValue;
        if(this.user.role=="Admin")
        {
                       this.isAdmin=true;
        }
    }

    ngOnInit() {
        this.bookService.getAll()
            .pipe(first())
            .subscribe(books => this.books = books);
           
    }
    

    deleteBook(id: string) {
        const book = this.books.find(x => x.id === id);
        book.isDeleting = true;
        this.bookService.delete(id)
            .pipe(first())
            .subscribe(() => {
                this.books = this.books.filter(x => x.id !== id) 
            });
    }
    
    subscribeBook(id: string) {
        const book = this.books.find(x => x.id === id);
      //  book.isDeleting = true;
  let bookUser:BookUser;
      if(book.userId==null || book.userId!=this.user.id.toUpperCase( ))
      {
//subscribe
bookUser=new BookUser();
bookUser.bookId=book.id;
bookUser.userId=this.user.id;
this.bookService.subscribe(bookUser)
.pipe(first())
.subscribe(() => {
    this.bookService.getAll()
.pipe(first())
.subscribe(books => this.books = books);
});

      } else
      {
        bookUser=new BookUser();
        bookUser.bookId=book.id;
        bookUser.userId=this.user.id;
        this.bookService.unsubscribe(bookUser)
        .pipe(first())
        .subscribe(() => {
            this.bookService.getAll()
        .pipe(first())
        .subscribe(books => this.books = books);
        });

      }

     
    }
}