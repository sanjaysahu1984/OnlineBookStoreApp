export class BookUser    {
      
      public  id:string;   
       public userId:string;
     public bookId:string;
    }