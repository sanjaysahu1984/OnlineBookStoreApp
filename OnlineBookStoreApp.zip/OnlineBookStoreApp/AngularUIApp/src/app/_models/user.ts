﻿export class User {
    id: string;
    emailAddress: string;
    password: string;
    firstName: string;
    lastName: string;
    role:string;
    token: string;
}