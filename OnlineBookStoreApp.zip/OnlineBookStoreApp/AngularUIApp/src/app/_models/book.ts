﻿export class Book {
    id: string;
    title: string;
    description: string;
    purchasePrice: Number;
    userId: string;
}