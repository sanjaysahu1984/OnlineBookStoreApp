﻿using AutoMapper;
using BookOnlineApp.DbContexts;
using BookOnlineApp.Entities;
using BookOnlineApp.Helpers;
using BookOnlineApp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace BookOnlineApp.Services
{
    public class BookRepository : IBookRepository
    {
        private readonly BookOnlineContext _context;
        private readonly ApplicationSettings _appSettings;
        private readonly IMapper _mapper;

        public BookRepository(BookOnlineContext context, IOptions<ApplicationSettings> appSettings,IMapper mapper)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _appSettings = appSettings.Value;
            _mapper = mapper ??
                throw new ArgumentNullException(nameof(mapper));
        }

        public void AddBook(BookDto book)
        {
            var bookEntity = _mapper.Map<Entities.Book>(book);
            _context.Books.Add(bookEntity);

        //    _context.Books.Add(book);
        }

        public void DeleteBook(Book book)
        {
            _context.Books.Remove(book);
        }

        public Book GetBook(Guid BookId)
        {
            if (BookId == Guid.Empty)
            {
                throw new ArgumentNullException(nameof(BookId));
            }

            return _context.Books.FirstOrDefault(a => a.Id == BookId);
        }

        public IEnumerable<BookDto> GetBooks()
        {
            var result = (from bk in _context.Books
                               join ub in _context.UserBooks on bk.Id equals ub.BookId into gj
                               from sub in gj.DefaultIfEmpty()
                               select new BookDto() { Id = bk.Id, Title = bk.Title, Description = bk.Description, PurchasePrice = bk.PurchasePrice, UserId = sub.UserId == Guid.Empty ? null : sub.UserId.ToString() }).ToList();
            return result;

           // return _context.Books.ToList<Book>();
        }

        public UserBook Subscribe(BookUserDto model)
        {
            var bookEntity = _mapper.Map<Entities.UserBook>(model);
            _context.UserBooks.Add(bookEntity);
        

            return bookEntity;
        }


        public UserBook UnSubscribe(BookUserDto model)
        {
            var bookEntity = _context.UserBooks.FirstOrDefault(c => (c.BookId == model.BookId && c.UserId == model.UserId));
            _context.UserBooks.Remove(bookEntity);

            return bookEntity;
        }





        public bool Save()
        {
            return (_context.SaveChanges() >= 0);
        }

        public void UpdateBook(BookDto Book)
        {
            var bookEntity = _mapper.Map<Entities.Book>(Book);

            _context.Entry(bookEntity).State = EntityState.Modified;

            _context.Books.Update(bookEntity);
        }
              
        public bool BookExists(Guid BookId)
        {
           var book= _context.Books.Find(BookId);
            if (book != null)
                return true;

            return false;
               
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // dispose resources when needed
            }
        }
    }
}
