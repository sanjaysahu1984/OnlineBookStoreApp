﻿using BookOnlineApp.Entities;
using BookOnlineApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookOnlineApp.Services
{
   public interface IUserRepository
    {
       
        IEnumerable<User> GetUsers();
        UserReturnDto UserAuthenticate(UserLoginDto user);
        User GetUser(Guid userId);       
        void AddUser(User user);
        void DeleteUser(User user);
        void UpdateUser(User user);
        bool UserExists(Guid userId);
        public bool UserExistsEmail(string emailAddress);
        bool Save();
    }
}
