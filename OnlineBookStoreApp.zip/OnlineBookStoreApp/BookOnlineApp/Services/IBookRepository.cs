﻿using BookOnlineApp.Entities;
using BookOnlineApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookOnlineApp.Services
{
   public interface IBookRepository
    {
       
        IEnumerable<BookDto> GetBooks();
        Book GetBook(Guid bookId);       
        void AddBook(BookDto book);
        void DeleteBook(Book book);
        void UpdateBook(BookDto book);
        bool BookExists(Guid bookId);
        UserBook Subscribe(BookUserDto model);
        UserBook UnSubscribe(BookUserDto model);

        bool Save();
    }
}
