﻿using AutoMapper;
using BookOnlineApp.DbContexts;
using BookOnlineApp.Entities;
using BookOnlineApp.Helpers;
using BookOnlineApp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace BookOnlineApp.Services
{
    public class UserRepository : IUserRepository
    {
        private readonly BookOnlineContext _context;
        private readonly ApplicationSettings _appSettings;
        private readonly IMapper _mapper;

        public UserRepository(BookOnlineContext context, IOptions<ApplicationSettings> appSettings,IMapper mapper)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _appSettings = appSettings.Value;
            _mapper = mapper ??
                throw new ArgumentNullException(nameof(mapper));
        }

        public void AddUser(User user)
        {
            var password = user.Password;

            var customPasswordHasher = new CustomPasswordHasher();
            var passwordHash = customPasswordHasher.HashPassword(password);

            user.Password= passwordHash;
            if(string.IsNullOrEmpty(user.Role))
            user.Role = Role.User;

            _context.Users.Add(user);
        }

        public void DeleteUser(User user)
        {
            _context.Users.Remove(user);
        }

        public User GetUser(Guid userId)
        {
            if (userId == Guid.Empty)
            {
                throw new ArgumentNullException(nameof(userId));
            }

            return _context.Users.FirstOrDefault(a => a.Id == userId);
        }

        public IEnumerable<User> GetUsers()
        {
            return _context.Users.ToList<User>();
        }

        public bool Save()
        {
            return (_context.SaveChanges() >= 0);
        }

        public void UpdateUser(User user)
        {
          
            var usr = GetUser(user.Id);
            _context.Entry(usr).State = EntityState.Modified;



            if (!String.Empty.Equals(user.Password.Trim()))
            {
                var password = user.Password;
                var customPasswordHasher = new CustomPasswordHasher();
                var passwordHash = customPasswordHasher.HashPassword(password);
                usr.Password = passwordHash;
            }
            
           

            if (!String.IsNullOrEmpty(user.FirstName))
                usr.FirstName = user.FirstName;
            if (!String.IsNullOrEmpty(user.LastName))
                usr.LastName = user.LastName;
            if (!String.IsNullOrEmpty(user.EmailAddress))
                usr.EmailAddress = user.EmailAddress;
            if (!String.IsNullOrEmpty(user.Role))
                usr.Role = user.Role;

            //_context.Attach(user);
          //  
            _context.Users.Update(usr);
        }

        public UserReturnDto UserAuthenticate(UserLoginDto user)
        {
            var customPasswordHasher = new CustomPasswordHasher();
           
            var userEntity = _context.Users.SingleOrDefault(x => x.EmailAddress.ToUpper() == user.EmailAddress.ToUpper() );

            // return null if user not found
            if (userEntity == null)
                return null;

            var isvalid= customPasswordHasher.VerifyPassword(userEntity.Password, user.Password);
            if (isvalid != true)
                return null;

            var userToReturn = _mapper.Map<UserReturnDto>(userEntity);

            // authentication successful so generate jwt token
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.JWT_Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Email, userToReturn.EmailAddress),
                    new Claim(ClaimTypes.Role, userToReturn.Role)
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            userToReturn.Token = tokenHandler.WriteToken(token);

            return userToReturn;
           
        }

        public bool UserExists(Guid userId)
        {
            var usr= _context.Users.Find(userId);
            if (usr == null)
                return false;

            return true;
        }

        public bool UserExistsEmail(string emailAddress)
        {
            var usr = _context.Users.FirstOrDefault(c=>c.EmailAddress==emailAddress);
            if (usr == null)
                return false;

            return true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // dispose resources when needed
            }
        }
    }
}
