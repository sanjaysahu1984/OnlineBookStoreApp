﻿using AutoMapper;
using BookOnlineApp.Entities;
using BookOnlineApp.Models;
using BookOnlineApp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;

namespace BookOnlineApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
     [Authorize(Roles = (Role.Admin + "," + Role.User + "," + Role.Reseller))]
    public class BooksController : ControllerBase
    {
   
        private readonly IBookRepository _bookRepository;
        private readonly IMapper _mapper;

        public BooksController(IBookRepository bookRepository, IMapper mapper)
        {
            _bookRepository = bookRepository ??
               throw new ArgumentNullException(nameof(bookRepository));
          
            _mapper = mapper ??
               throw new ArgumentNullException(nameof(mapper));
        }

        // GET: api/Books
       
        [HttpGet]
        public IActionResult GetBooks()
        { 
            var result = _bookRepository.GetBooks();
            return Ok(result);
        
        }

        [HttpPost("subscribe")]
        public  IActionResult Subscribe([FromBody] BookUserDto model)
        {
            //var bookEntity = _mapper.Map<Entities.UserBook>(model);
            //_context.UserBooks.Add(bookEntity);
            //await _context.SaveChangesAsync();

            //return Ok(bookEntity);

           var bookEnitity= _bookRepository.Subscribe(model);
            _bookRepository.Save();

            return Ok(bookEnitity);

        }

        [HttpPost("unsubscribe")]
        public IActionResult UnSubscribe([FromBody] BookUserDto model)
        {

            //var bookEntity = _context.UserBooks.FirstOrDefault(c=>(c.BookId==model.BookId && c.UserId==model.UserId));
            // _context.UserBooks.Remove(bookEntity);
            // await _context.SaveChangesAsync();

            var bookEnitity = _bookRepository.UnSubscribe(model);
            _bookRepository.Save();

            return Ok(bookEnitity);
        }



        // GET: api/Books/5
        [HttpGet("{id}")]
        public ActionResult<Book> GetBook(Guid id)
        {
            //var book = await _context.Books.FindAsync(id);

            //if (book == null)
            //{
            //    return NotFound();
            //}
          var book=  _bookRepository.GetBook(id);
            if (book == null)
            {
                return NotFound();
            }
            return book;
        }

        // PUT: api/Books/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public IActionResult PutBook(Guid id, BookDto book)
        {
            
                  book.Id = id;
            _bookRepository.UpdateBook(book);
            _bookRepository.Save();
            //      var bookEntity = _mapper.Map<Entities.Book>(book);

            //_context.Entry(bookEntity).State = EntityState.Modified;

            try
            {
                _bookRepository.Save();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BookExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Books
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public  ActionResult<Book> PostBook(BookDto book)
        {
            //var bookEntity = _mapper.Map<Entities.Book>(book);
            //_context.Books.Add(bookEntity);
            //await _context.SaveChangesAsync();

            _bookRepository.AddBook(book);
            _bookRepository.Save();

            return CreatedAtAction("GetBook", new { id = book.Id }, book);
        }

        // DELETE: api/Books/5
        [HttpDelete("{id}")]
        public ActionResult<Book> DeleteBook(Guid id)
        {
           // var book = await _context.Books.FindAsync(id);
            var book = _bookRepository.GetBook(id);
            if (book == null)
            {
                return NotFound();
            }
            _bookRepository.DeleteBook(book);
            _bookRepository.Save();
          //  _context.Books.Remove(book);
         //   await _context.SaveChangesAsync();

            return book;
        }

        private bool BookExists(Guid id)
        {
           return _bookRepository.BookExists(id);
        }
    }
}
