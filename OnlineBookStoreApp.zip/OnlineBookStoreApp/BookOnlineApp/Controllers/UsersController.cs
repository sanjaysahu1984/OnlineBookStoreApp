﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using BookOnlineApp.Entities;
using BookOnlineApp.Models;
using BookOnlineApp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace BookOnlineApp.Controllers
{
    [ApiController]
    [Route("api/users")]
    public class UsersController : ControllerBase
    {
    
        private readonly IUserRepository _userRepository;
        private readonly IMapper _mapper;

        public UsersController(IUserRepository userRepository, IMapper mapper)
        {
            _userRepository = userRepository ??
                throw new ArgumentNullException(nameof(userRepository));
            _mapper = mapper ??
                throw new ArgumentNullException(nameof(mapper));
        }

        [HttpPost]
        public ActionResult<UserDto> CreateUser(UserDto _user)
        {
            if (_user.EmailAddress != null)
            {
                if (_userRepository.UserExistsEmail(_user.EmailAddress))
                {
                    return Conflict(_user);
                }
            }

            var userEntity = _mapper.Map<Entities.User>(_user);



            _userRepository.AddUser(userEntity);
           _userRepository.Save();

            var userToReturn = _mapper.Map<UserReturnDto>(userEntity);
            return CreatedAtRoute("GetUser",
                new { userId = userToReturn.Id },
                userToReturn);

        }

        // DELETE: api/Users/5
        [HttpDelete("{id}")]
        public ActionResult<User> DeleteUser(Guid id)
        {
    
            var user = _userRepository.GetUser(id);
            if (user == null)
            {
                return NotFound();
            }
            _userRepository.DeleteUser(user);
            _userRepository.Save();
          
            return user;
        }


        [HttpPut("{id}")]
        public ActionResult<UserDto> UpdateUser(Guid id, UserDto _user)
        {
           
            if (!_userRepository.UserExists(id))
            {
                return NotFound(_user);
            }

            _user.Id = id;

            

            var userEntity = _mapper.Map<Entities.User>(_user);
            _userRepository.UpdateUser(userEntity);
                    _userRepository.Save();
                        

            var userToReturn = _mapper.Map<UserReturnDto>(userEntity);
            return CreatedAtRoute("GetUser",
                new { userId = userToReturn.Id },
                userToReturn);

        }
               
        [HttpGet("{userId}", Name = "GetUser")]
        public IActionResult GetUser(Guid userId)
        {
            var userFromRepo = _userRepository.GetUser(userId);

            if (userFromRepo == null)
            {
                return NotFound();
            }

            return Ok(_mapper.Map<UserReturnDto>(userFromRepo));
        }

        [AllowAnonymous]
        [HttpPost("authenticate")]
        public IActionResult Authenticate([FromBody] UserLoginDto model)
        {
            var _user = _userRepository.UserAuthenticate(model);

            if (_user == null)
                return BadRequest(new { message = "Username or password is incorrect" });

            return Ok(_user);
        }

        [Authorize(Roles = Role.Admin)]
        [HttpGet]
        public IActionResult GetAll()
        {
            var users = _userRepository.GetUsers();
            return Ok(users);
        }


    }
}
