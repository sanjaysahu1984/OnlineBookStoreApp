﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookOnlineApp.Entities
{
    public static class Role
    {
        public const string Admin = "Admin";
        public const string Reseller = "Reseller";
        public const string User = "User";
    }
}
