﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BookOnlineApp.Entities
{
    public class Book
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Title { get; set; }
                
        [MaxLength(1500)]
        public string Description { get; set; }

        [Required]
        [MaxLength(10)]
        public float PurchasePrice { get; set; }
       
    }
}
