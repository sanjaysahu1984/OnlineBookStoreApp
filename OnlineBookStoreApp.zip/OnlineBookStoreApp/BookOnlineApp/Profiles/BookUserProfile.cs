﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookOnlineApp.Profiles
{
    public class BookUserProfile : Profile
    {
        public BookUserProfile()
        {
            CreateMap<Models.BookUserDto, Entities.UserBook>();
        }
    }
}
