﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookOnlineApp.Profiles
{
    public class UsersProfile : Profile
    {
        public UsersProfile()
        {
        
            CreateMap<Models.UserDto, Entities.User>();
            CreateMap<Entities.User, Models.UserReturnDto>();
          
        }
    }
}
