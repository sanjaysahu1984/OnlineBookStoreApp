﻿using BookOnlineApp.Entities;
using BookOnlineApp.Helpers;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace BookOnlineApp.DbContexts
{
    public class BookOnlineContext : DbContext
    {
        public BookOnlineContext(DbContextOptions<BookOnlineContext> options) : base(options)
        {
        }
        public DbSet<User> Users { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<UserBook> UserBooks { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
           var customPasswordHasher = new CustomPasswordHasher();         
            // seed the database with dummy data
            modelBuilder.Entity<User>().HasData(
                new User()
                {
                    Id = Guid.Parse("d28888e9-2ba9-473a-a40f-e38cb54f9b35"),
                    FirstName = "Sanjay",
                    LastName = "Sahu",
                    EmailAddress ="sanjay@gmail.com",
                    Password = customPasswordHasher.HashPassword("SanjaySahu"),
                    Role=Role.Admin
                },
                new User()
                {
                    Id = Guid.Parse("da2fd609-d754-4feb-8acd-c4f9ff13ba96"),
                    FirstName = "Vinay",
                    LastName = "Kumar",
                    EmailAddress = "vinay@gmail.com",
                    Password = customPasswordHasher.HashPassword("SanjaySahu"),
                    Role = Role.Reseller
                },
                new User()
                {
                    Id = Guid.Parse("2902b665-1190-4c70-9915-b9c2d7680450"),
                    FirstName = "Ajay",
                    LastName = "Verma",
                    EmailAddress = "berry@gmail.com",
                    Password = customPasswordHasher.HashPassword("SanjaySahu"),
                    Role = Role.User
                }
                );
          

           modelBuilder.Entity<Book>().HasData(
               new Book
               {
                   Id = Guid.Parse("5b1c2b4d-48c7-402a-80c3-cc796ad49c6b"),
                   Title = "Commandeering a Ship Without Getting Caught",
                   PurchasePrice = 12,
                   Description = "Commandeering a ship in rough waters isn't easy.  Commandeering it without getting caught is even harder.  In this Book you'll learn how to sail away and avoid those pesky musketeers."
                  
               },
               new Book
               {
                   Id = Guid.Parse("d8663e5e-7494-4f81-8739-6e0de1bea7ee"),                  
                   Title = "Overthrowing Mutiny",
                   PurchasePrice = 54,
                   Description = "In this Book, the author provides tips to avoid, or, if needed, overthrow pirate mutiny."
               },
               new Book
               {
                   Id = Guid.Parse("d173e20d-159e-4127-9ce9-b0ac2564ad97"),                  
                   Title = "Avoiding Brawls While Drinking as Much Rum as You Desire",
                   PurchasePrice = 23,
                   Description = "Every good pirate loves rum, but it also has a tendency to get you into trouble.  In this Book you'll learn how to avoid that.  This new exclusive edition includes an additional chapter on how to run fast without falling while drunk."
               },
               new Book
               {
                   Id = Guid.Parse("40ff5488-fdab-45b5-bc3a-14302d59869a"),                 
                   Title = "Singalong Pirate Hits",
                   PurchasePrice = 13,
                   Description = "In this Book you'll learn how to sing all-time favourite pirate songs without sounding like you actually know the words or how to hold a note."
               }
               ) ;

            modelBuilder.Entity<UserBook>().HasData(
             new UserBook
             {
                 Id = Guid.NewGuid(),
                 UserId = Guid.Parse("da2fd609-d754-4feb-8acd-c4f9ff13ba96"),
                 BookId = Guid.Parse("5b1c2b4d-48c7-402a-80c3-cc796ad49c6b")
             },
              new UserBook
              {
                  Id= Guid.NewGuid(),
                  UserId = Guid.Parse("da2fd609-d754-4feb-8acd-c4f9ff13ba96"),
                  BookId = Guid.Parse("40ff5488-fdab-45b5-bc3a-14302d59869a")
              }
              ); ;

            base.OnModelCreating(modelBuilder);

        }

    }
}
