﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace BookOnlineApp.Migrations
{
    public partial class Init1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserBooks_Books_BookId",
                table: "UserBooks");

            migrationBuilder.DropForeignKey(
                name: "FK_UserBooks_Users_UserId",
                table: "UserBooks");

            migrationBuilder.DropIndex(
                name: "IX_UserBooks_BookId",
                table: "UserBooks");

            migrationBuilder.DropIndex(
                name: "IX_UserBooks_UserId",
                table: "UserBooks");

            migrationBuilder.DeleteData(
                table: "UserBooks",
                keyColumn: "Id",
                keyValue: new Guid("01d53e23-6feb-4634-8da4-531ab8043fdd"));

            migrationBuilder.DeleteData(
                table: "UserBooks",
                keyColumn: "Id",
                keyValue: new Guid("cfb5e249-4b5b-4c34-a76a-9c23edbcd480"));

            migrationBuilder.InsertData(
                table: "UserBooks",
                columns: new[] { "Id", "BookId", "UserId" },
                values: new object[,]
                {
                    { new Guid("04a9b1ce-5051-4169-ae68-e37baf6ed69a"), new Guid("5b1c2b4d-48c7-402a-80c3-cc796ad49c6b"), new Guid("da2fd609-d754-4feb-8acd-c4f9ff13ba96") },
                    { new Guid("b01cad56-896f-4e9d-83f0-cc30bb04643d"), new Guid("40ff5488-fdab-45b5-bc3a-14302d59869a"), new Guid("da2fd609-d754-4feb-8acd-c4f9ff13ba96") }
                });

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("2902b665-1190-4c70-9915-b9c2d7680450"),
                column: "Password",
                value: "AQAAAAEAACcQAAAAEPsicqQ5W3nLwuZABZQhJ9r6Li8cyDl6qVL85pih1BYsfMaXci/GDVHHkZqRhVpLMw==");

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("d28888e9-2ba9-473a-a40f-e38cb54f9b35"),
                column: "Password",
                value: "AQAAAAEAACcQAAAAEBFooj1yC6cjguL8bKLYZZB2pODmLbkpdd/aEGKzVILwTH3UPYCi248bKR+0ZWx0Gw==");

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("da2fd609-d754-4feb-8acd-c4f9ff13ba96"),
                column: "Password",
                value: "AQAAAAEAACcQAAAAEKE6hS3igE5e8Zy8FHGOLBBpaZKHZ5yym+IaxXarApwg9X1S5sSZGaW/tWz8NApzug==");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "UserBooks",
                keyColumn: "Id",
                keyValue: new Guid("04a9b1ce-5051-4169-ae68-e37baf6ed69a"));

            migrationBuilder.DeleteData(
                table: "UserBooks",
                keyColumn: "Id",
                keyValue: new Guid("b01cad56-896f-4e9d-83f0-cc30bb04643d"));

            migrationBuilder.InsertData(
                table: "UserBooks",
                columns: new[] { "Id", "BookId", "UserId" },
                values: new object[,]
                {
                    { new Guid("cfb5e249-4b5b-4c34-a76a-9c23edbcd480"), new Guid("5b1c2b4d-48c7-402a-80c3-cc796ad49c6b"), new Guid("da2fd609-d754-4feb-8acd-c4f9ff13ba96") },
                    { new Guid("01d53e23-6feb-4634-8da4-531ab8043fdd"), new Guid("40ff5488-fdab-45b5-bc3a-14302d59869a"), new Guid("da2fd609-d754-4feb-8acd-c4f9ff13ba96") }
                });

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("2902b665-1190-4c70-9915-b9c2d7680450"),
                column: "Password",
                value: "AQAAAAEAACcQAAAAEH1y2p1++VEx4Q0GVsDiyl+Fcsf7nPrtK8AcXBkpqFwrHn4Vps5QC+l0Yyxt6ji3pQ==");

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("d28888e9-2ba9-473a-a40f-e38cb54f9b35"),
                column: "Password",
                value: "AQAAAAEAACcQAAAAELvxWJRfdK6GKDA2LF0//2iu5jlMOhaNPs7dHMECpmm6QCY6Lp9MHvMPe4UJphMmRA==");

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("da2fd609-d754-4feb-8acd-c4f9ff13ba96"),
                column: "Password",
                value: "AQAAAAEAACcQAAAAEGGFOR0pf47WikbqgGJ7T0FS4986UHUsN64KZuJ/JJ0NmfH4VGZ6nBHDHXha36ajtg==");

            migrationBuilder.CreateIndex(
                name: "IX_UserBooks_BookId",
                table: "UserBooks",
                column: "BookId");

            migrationBuilder.CreateIndex(
                name: "IX_UserBooks_UserId",
                table: "UserBooks",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_UserBooks_Books_BookId",
                table: "UserBooks",
                column: "BookId",
                principalTable: "Books",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UserBooks_Users_UserId",
                table: "UserBooks",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
